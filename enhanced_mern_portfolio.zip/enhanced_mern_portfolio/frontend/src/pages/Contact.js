import { motion } from 'framer-motion';

const Contact = () => (
  <motion.div
    className="min-h-screen bg-gradient-to-r from-sky-400 to-violet-600 text-white p-6"
    initial={{ scale: 0.8 }}
    animate={{ scale: 1 }}
    transition={{ duration: 0.5 }}
  >
    <h2 className="text-4xl font-bold mb-4">Contact</h2>
    <p className="text-lg">Email: Harivettri8778@gmail.com</p>
  </motion.div>
);

export default Contact;
