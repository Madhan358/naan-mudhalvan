import { motion } from 'framer-motion';

const Home = () => (
  <motion.div
    className="min-h-screen bg-gradient-to-r from-sky-400 to-violet-600 flex flex-col items-center justify-center text-white text-center"
    initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    transition={{ duration: 1 }}
  >
    <h1 className="text-5xl font-bold mb-4">Hi, we are team TECHAKATSUKI</h1>
    <p className="text-2xl">Full Stack Developer | MERN Enthusiast</p>
  </motion.div>
);

export default Home;
