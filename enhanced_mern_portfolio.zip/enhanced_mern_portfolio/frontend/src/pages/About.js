import { motion } from 'framer-motion';

const About = () => (
  <motion.div
    className="min-h-screen bg-gradient-to-r from-sky-400 to-violet-600 text-white p-6"
    initial={{ x: '-100vw' }}
    animate={{ x: 0 }}
    transition={{ type: 'spring', stiffness: 50 }}
  >
    <h2 className="text-4xl font-bold mb-4">About Me</h2>
    <p className="text-lg">we are team techakatsuki membere: Hari Prasath,Jeeva,MohmadIbhrahim,Jaiakash,Madhan</p>
  </motion.div>
);

export default About;
