import { useEffect, useState } from 'react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../firebase';
import { motion } from 'framer-motion';

const Projects = () => {
  const [projects, setProjects] = useState([]);

  useEffect(() => {
    const fetchProjects = async () => {
      const querySnapshot = await getDocs(collection(db, "projects"));
      setProjects(querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    };
    fetchProjects();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-r from-sky-400 to-violet-600 text-white p-6">
      <motion.h2
        className="text-4xl font-bold mb-4"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        My Projects
      </motion.h2>
      <div className="grid md:grid-cols-2 gap-6">
        {projects.map(p => (
          <motion.div
            key={p.id}
            className="bg-white/10 p-4 rounded-xl shadow-lg backdrop-blur-md"
            whileHover={{ scale: 1.05 }}
            transition={{ duration: 0.3 }}
          >
            <h3 className="text-xl font-semibold">{p.title}</h3>
            <p>{p.description}</p>
            <div className="mt-2">
              <a href={p.github} className="text-blue-200">GitHub</a> | 
              <a href={p.demo} className="text-purple-200 ml-2">Live Demo</a>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default Projects;
